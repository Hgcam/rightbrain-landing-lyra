Rightbrain brand kit
====================

Logo files (in /logo)
  rightbrain-logotype-light.svg / .png   Full lockup, full-colour, for light backgrounds
  rightbrain-logotype-dark.svg  / .png   Full lockup, reverse, for dark backgrounds
  rightbrain-logotype-light-mono.svg     Full lockup, single-colour (dark), light bg
  rightbrain-logotype-dark-mono.svg      Full lockup, single-colour (light), dark bg
  rightbrain-icon-light.svg / .png       Icon only, for light backgrounds
  rightbrain-icon-dark.svg  / .png       Icon only, for dark backgrounds
  rightbrain-icon-light-mono.svg         Icon, single-colour (dark)
  rightbrain-icon-dark-mono.svg          Icon, single-colour (light)
All SVG/PNG marks have transparent backgrounds.

Favicons (in /favicon)
  favicon.svg          Self-contained tile, legible on light + dark browser tabs
  favicon.ico          16 / 32 / 48 raster fallback
  favicon-16/32/48.png Individual raster sizes
  apple-touch-icon.png 180px (opaque, for iOS home screen)
  icon-512.png         512px (PWA / high-res)

Colour
  Orange   #EA580C   Primary accent
  Ink      #1C1917   Text / dark surfaces
  Paper    #FFFFFF   Light surfaces
  Stone    #78716C   Secondary text
  Line     #E7E5E4   Borders

Type
  Merriweather   headlines & long-form (Google Fonts)
  JetBrains Mono interface, labels, data (Google Fonts)

Usage: do not alter, recolour, rotate or add effects. Keep 1x icon-height clear
space. Questions: press@rightbrain.ai
